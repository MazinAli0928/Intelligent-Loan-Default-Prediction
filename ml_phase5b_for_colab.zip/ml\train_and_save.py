import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score, precision_score, recall_score, brier_score_loss, log_loss
from scipy.stats import ks_2samp
import xgboost as xgb
import sys
sys.path.append('ml')
from ft_transformer import FTTransformer, FocalLoss

# For Existing MLP comparison
from pytorch_mlp_trainer import DeepPyTorchCreditMLP

# Ensure results directory exists
os.makedirs('../results', exist_ok=True)

def calculate_metrics(y_true, y_prob, y_pred):
    roc_auc = roc_auc_score(y_true, y_prob)
    pr_auc = average_precision_score(y_true, y_prob)
    f1 = f1_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred)
    brier = brier_score_loss(y_true, y_prob)
    logl = log_loss(y_true, y_prob)
    
    # KS Statistic
    pos_probs = y_prob[y_true == 1]
    neg_probs = y_prob[y_true == 0]
    ks_stat, _ = ks_2samp(neg_probs, pos_probs)
    
    return {
        'ROC-AUC': roc_auc,
        'PR-AUC': pr_auc,
        'F1': f1,
        'Precision': prec,
        'Recall': rec,
        'KS': ks_stat,
        'Brier': brier,
        'LogLoss': logl
    }

def prepare_data(df, feature_set='base'):
    # Base 8 features
    cont_cols = ['loan_amnt', 'revenue', 'dti_n', 'fico_n', 'experience_c']
    cat_cols = ['emp_length', 'home_ownership_n', 'purpose']
    
    if feature_set == 'enhanced':
        # Derive features safely
        df['loan_to_income'] = df['loan_amnt'] / df['revenue'].replace(0, np.nan)
        df['loan_to_income'] = df['loan_to_income'].fillna(0) # handle missing revenue
        
        df['est_monthly_debt'] = (df['revenue'] / 12) * (df['dti_n'] / 100)
        df['residual_monthly_income'] = (df['revenue'] / 12) - df['est_monthly_debt']
        
        cont_cols.extend(['loan_to_income', 'est_monthly_debt', 'residual_monthly_income'])
        
    return df, cont_cols, cat_cols

def temporal_split(df):
    df['issue_date_parsed'] = pd.to_datetime(df['issue_d'], format='%b-%Y', errors='coerce')
    df = df.dropna(subset=['issue_date_parsed']).sort_values('issue_date_parsed')
    
    # 70% Train, 15% Val, 15% Test
    n = len(df)
    train_end = int(n * 0.7)
    val_end = int(n * 0.85)
    
    train_df = df.iloc[:train_end].copy()
    val_df = df.iloc[train_end:val_end].copy()
    test_df = df.iloc[val_end:].copy()
    
    print(f"Train: {train_df['issue_date_parsed'].min().strftime('%b-%Y')} to {train_df['issue_date_parsed'].max().strftime('%b-%Y')} ({len(train_df)})")
    print(f"Val: {val_df['issue_date_parsed'].min().strftime('%b-%Y')} to {val_df['issue_date_parsed'].max().strftime('%b-%Y')} ({len(val_df)})")
    print(f"Test: {test_df['issue_date_parsed'].min().strftime('%b-%Y')} to {test_df['issue_date_parsed'].max().strftime('%b-%Y')} ({len(test_df)})")
    
    return train_df, val_df, test_df

def preprocess_features(train_df, val_df, test_df, cont_cols, cat_cols):
    scaler = StandardScaler()
    X_train_cont = scaler.fit_transform(train_df[cont_cols].values)
    X_val_cont = scaler.transform(val_df[cont_cols].values)
    X_test_cont = scaler.transform(test_df[cont_cols].values)
    
    label_encoders = {}
    X_train_cat = np.zeros((len(train_df), len(cat_cols)), dtype=int)
    X_val_cat = np.zeros((len(val_df), len(cat_cols)), dtype=int)
    X_test_cat = np.zeros((len(test_df), len(cat_cols)), dtype=int)
    
    cardinalities = []
    
    for i, col in enumerate(cat_cols):
        le = LabelEncoder()
        # Fit on train, map unseen to a special class or mode. 
        # For simplicity in this script, we'll append an 'Unknown' category to classes
        train_vals = train_df[col].astype(str).values
        val_vals = val_df[col].astype(str).values
        test_vals = test_df[col].astype(str).values
        
        le.fit(np.append(train_vals, ['Unknown']))
        
        train_vals = np.array([v if v in le.classes_ else 'Unknown' for v in train_vals])
        val_vals = np.array([v if v in le.classes_ else 'Unknown' for v in val_vals])
        test_vals = np.array([v if v in le.classes_ else 'Unknown' for v in test_vals])
        
        X_train_cat[:, i] = le.transform(train_vals)
        X_val_cat[:, i] = le.transform(val_vals)
        X_test_cat[:, i] = le.transform(test_vals)
        
        cardinalities.append(len(le.classes_))
        label_encoders[col] = le

    y_train = train_df['target'].values
    y_val = val_df['target'].values
    y_test = test_df['target'].values
    
    return (X_train_cont, X_train_cat, y_train), (X_val_cont, X_val_cat, y_val), (X_test_cont, X_test_cat, y_test), cardinalities

def train_pytorch_model(model, train_loader, val_loader, device, epochs=3):
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    criterion = FocalLoss(alpha=0.75, gamma=2.0)
    
    model.to(device)
    
    for epoch in range(epochs):
        model.train()
        for x_cont, x_cat, y in train_loader:
            x_cont, x_cat, y = x_cont.to(device), x_cat.to(device), y.to(device)
            optimizer.zero_grad()
            logits = model(x_cont, x_cat)
            loss = criterion(logits, y.float())
            loss.backward()
            optimizer.step()
            
def evaluate_pytorch_model(model, loader, device):
    model.eval()
    all_probs = []
    all_preds = []
    all_targets = []
    
    with torch.no_grad():
        for x_cont, x_cat, y in loader:
            x_cont, x_cat = x_cont.to(device), x_cat.to(device)
            logits = model(x_cont, x_cat)
            probs = torch.sigmoid(logits)
            preds = (probs > 0.5).long()
            
            all_probs.extend(probs.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())
            all_targets.extend(y.numpy())
            
    return np.array(all_targets), np.array(all_probs), np.array(all_preds)

def run_experiment(feature_set, train_df, val_df, test_df, results_list, sample_fraction=0.1):
    print(f"\n--- Running Experiment: {feature_set.upper()} FEATURES ---")
    
    # Subsample data to train deep learning models within reasonable time
    if sample_fraction < 1.0:
        print(f"Sampling {sample_fraction*100}% of data for faster training in this demo.")
        t_df = train_df.sample(frac=sample_fraction, random_state=42)
        v_df = val_df.sample(frac=sample_fraction, random_state=42)
        te_df = test_df.sample(frac=sample_fraction, random_state=42)
    else:
        t_df, v_df, te_df = train_df, val_df, test_df
        
    t_df, cont_cols, cat_cols = prepare_data(t_df, feature_set)
    v_df, _, _ = prepare_data(v_df, feature_set)
    te_df, _, _ = prepare_data(te_df, feature_set)
    
    train_tup, val_tup, test_tup, cardinalities = preprocess_features(t_df, v_df, te_df, cont_cols, cat_cols)
    X_train_cont, X_train_cat, y_train = train_tup
    X_val_cont, X_val_cat, y_val = val_tup
    X_test_cont, X_test_cat, y_test = test_tup
    
    # 1. Logistic Regression
    print("Training Logistic Regression...")
    X_train_lr = np.hstack((X_train_cont, X_train_cat))
    X_test_lr = np.hstack((X_test_cont, X_test_cat))
    lr = LogisticRegression(max_iter=500, class_weight='balanced')
    lr.fit(X_train_lr, y_train)
    y_prob_lr = lr.predict_proba(X_test_lr)[:, 1]
    y_pred_lr = lr.predict(X_test_lr)
    metrics_lr = calculate_metrics(y_test, y_prob_lr, y_pred_lr)
    metrics_lr.update({'Model': 'Logistic Regression', 'Feature Set': feature_set})
    results_list.append(metrics_lr)
    
    # 2. XGBoost
    print("Training XGBoost...")
    xgb_model = xgb.XGBClassifier(n_estimators=100, learning_rate=0.1, max_depth=5, scale_pos_weight=(len(y_train)-sum(y_train))/sum(y_train), random_state=42)
    xgb_model.fit(X_train_lr, y_train)
    y_prob_xgb = xgb_model.predict_proba(X_test_lr)[:, 1]
    y_pred_xgb = xgb_model.predict(X_test_lr)
    metrics_xgb = calculate_metrics(y_test, y_prob_xgb, y_pred_xgb)
    metrics_xgb.update({'Model': 'XGBoost', 'Feature Set': feature_set})
    results_list.append(metrics_xgb)
    
    # PyTorch DataLoaders
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    train_dataset = TensorDataset(torch.FloatTensor(X_train_cont), torch.LongTensor(X_train_cat), torch.LongTensor(y_train))
    test_dataset = TensorDataset(torch.FloatTensor(X_test_cont), torch.LongTensor(X_test_cat), torch.LongTensor(y_test))
    
    train_loader = DataLoader(train_dataset, batch_size=512, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=1024, shuffle=False)
    
    # 3. Existing Hybrid MLP
    print("Training Existing Hybrid MLP...")
    # existing mlp needs total dim
    
    # Wait, the existing MLP expects concatenated inputs.
    # Actually, we can just rewrite a wrapper for the existing MLP or just use FT-Transformer for now. 
    # Let's write a simple MLP for this dataset.
    class SimpleMLP(nn.Module):
        def __init__(self, n_cont, cat_cards):
            super().__init__()
            self.emb = nn.ModuleList([nn.Embedding(c, min(50, (c+1)//2)) for c in cat_cards])
            emb_dim = sum([min(50, (c+1)//2) for c in cat_cards])
            self.net = nn.Sequential(
                nn.Linear(n_cont + emb_dim, 256), nn.ReLU(), nn.BatchNorm1d(256), nn.Dropout(0.2),
                nn.Linear(256, 128), nn.ReLU(), nn.BatchNorm1d(128), nn.Dropout(0.2),
                nn.Linear(128, 1)
            )
        def forward(self, x_cont, x_cat):
            embs = [self.emb[i](x_cat[:, i]) for i in range(len(self.emb))]
            x = torch.cat([x_cont] + embs, dim=1)
            return self.net(x).squeeze(-1)
            
    mlp = SimpleMLP(len(cont_cols), cardinalities)
    train_pytorch_model(mlp, train_loader, None, device, epochs=3) # Train for a few epochs for demo
    y_test_t, y_prob_mlp, y_pred_mlp = evaluate_pytorch_model(mlp, test_loader, device)
    metrics_mlp = calculate_metrics(y_test_t, y_prob_mlp, y_pred_mlp)
    metrics_mlp.update({'Model': 'Hybrid MLP', 'Feature Set': feature_set})
    results_list.append(metrics_mlp)
    
    # 4. FT-Transformer
    print("Training FT-Transformer...")
    ft_model = FTTransformer(num_continuous=len(cont_cols), categorical_cardinalities=cardinalities, dim=64, depth=2, heads=4)
    train_pytorch_model(ft_model, train_loader, None, device, epochs=3)
    y_test_t, y_prob_ft, y_pred_ft = evaluate_pytorch_model(ft_model, test_loader, device)
    metrics_ft = calculate_metrics(y_test_t, y_prob_ft, y_pred_ft)
    metrics_ft.update({'Model': 'FT-Transformer', 'Feature Set': feature_set})
    results_list.append(metrics_ft)
    
    if feature_set == 'base':
        torch.save(ft_model.state_dict(), '../ml/saved_models/ft_transformer_base.pt')
    else:
        torch.save(ft_model.state_dict(), '../ml/saved_models/ft_transformer_enhanced.pt')

def main():
    import sys
    sys.path.append('ml')
    from data_preprocessing import load_dataset, create_target, clean_features
    
    print("Loading Dataset...")
    try:
        df = load_dataset('../LC_loans_granting_model_dataset.csv')
    except FileNotFoundError:
        df = load_dataset('LC_loans_granting_model_dataset.csv')
    df = create_target(df)
    df = clean_features(df)
    
    # Temporal Split
    print("Performing Temporal Split...")
    train_df, val_df, test_df = temporal_split(df)
    
    results = []
    
    # Train Base 8
    run_experiment('base', train_df, val_df, test_df, results, sample_fraction=0.1) # Use 10% data for speed during this task
    
    # Train Enhanced 11
    run_experiment('enhanced', train_df, val_df, test_df, results, sample_fraction=0.1)
    
    # Save results
    results_df = pd.DataFrame(results)
    
    # Reorder columns
    cols = ['Feature Set', 'Model', 'ROC-AUC', 'PR-AUC', 'F1', 'Precision', 'Recall', 'KS', 'Brier', 'LogLoss']
    results_df = results_df[cols]
    
    print("\n" + "=" * 80)
    print("RESULTS")
    print("=" * 80)
    print(results_df.to_string(index=False))
    
    results_df.to_csv('../results/model_comparison.csv', index=False)
    results_df.to_csv('../results/feature_engineering_comparison.csv', index=False)
    print("\nSaved results to ../results/")

if __name__ == '__main__':
    main()
