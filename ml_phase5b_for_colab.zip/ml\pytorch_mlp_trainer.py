﻿"""
Hybrid MLP Credit Risk Engine - PyTorch Deep MLP with:
  Entity Embeddings, Non-linear Feature Ratios, Focal Loss,
  Stratified 5-Fold CV, Gradient x Input Attribution, Save/Load.
"""
from __future__ import annotations
import json, math, random
import torch
import torch.nn as nn
import torch.optim as optim
from dataclasses import dataclass
from pathlib import Path
from torch.utils.data import DataLoader, TensorDataset

SEGMENT_MAP = {"salaried_prime": 0, "self_employed": 1, "micro_business": 2, "new_to_credit": 3}
GENDER_MAP  = {"male": 0, "female": 1}
CITY_MAP    = {"Mumbai": 0, "Bengaluru": 1, "Hyderabad": 2, "Ahmedabad": 3}

FEATURE_LABELS = [
    ("credit_score",        "Credit Bureau Score"),
    ("dti_ratio",           "Debt-to-Income Ratio"),
    ("affordability",       "Loan Affordability Index"),
    ("surplus_cashflow",    "Surplus Cashflow Margin"),
    ("credit_burden",       "Credit Burden Ratio"),
    ("employment_years",    "Employment Stability"),
    ("existing_loans",      "Existing Loan Obligations"),
    ("savings_consistency", "Savings Consistency Signal"),
    ("log_income",          "Log Monthly Income"),
    ("log_amount",          "Log Loan Amount"),
]
CAT_CARDINALITIES = [4, 2, 4]
EMB_DIMS          = [4, 2, 4]
NUM_CONTINUOUS    = len(FEATURE_LABELS)


def compute_auc_roc(y_true: torch.Tensor, y_pred: torch.Tensor) -> float:
    y_true = y_true.squeeze(); y_pred = y_pred.squeeze()
    n_pos = (y_true == 1.0).sum().item(); n_neg = (y_true == 0.0).sum().item()
    if n_pos == 0 or n_neg == 0: return 0.5
    ranks = torch.argsort(torch.argsort(y_pred)) + 1
    u = ranks[y_true == 1.0].sum().item() - n_pos * (n_pos + 1) / 2.0
    return float(u / (n_pos * n_neg))


def compute_ks_statistic(y_true: torch.Tensor, y_pred: torch.Tensor) -> float:
    y_true = y_true.squeeze(); y_pred = y_pred.squeeze()
    pos = y_pred[y_true == 1.0]; neg = y_pred[y_true == 0.0]
    if len(pos) == 0 or len(neg) == 0: return 0.0
    max_ks = 0.0
    for t in torch.linspace(0.0, 1.0, 200):
        tv = t.item()
        ks = abs((pos >= tv).float().mean().item() - (neg >= tv).float().mean().item())
        if ks > max_ks: max_ks = ks
    return float(max_ks)


class DeepPyTorchCreditMLP(nn.Module):
    def __init__(self, num_continuous=NUM_CONTINUOUS, cat_cardinalities=CAT_CARDINALITIES,
                 emb_dims=EMB_DIMS, hidden_dims=None, dropout_rate=0.20):
        super().__init__()
        if hidden_dims is None: hidden_dims = [512, 256, 128]
        self.embeddings = nn.ModuleList([nn.Embedding(nc, ed) for nc, ed in zip(cat_cardinalities, emb_dims)])
        total_input = num_continuous + sum(emb_dims)
        self.net = nn.Sequential(
            nn.Linear(total_input, hidden_dims[0]), nn.BatchNorm1d(hidden_dims[0]), nn.SiLU(), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dims[0], hidden_dims[1]), nn.BatchNorm1d(hidden_dims[1]), nn.SiLU(), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dims[1], hidden_dims[2]), nn.BatchNorm1d(hidden_dims[2]), nn.SiLU(), nn.Dropout(dropout_rate / 2),
            nn.Linear(hidden_dims[2], 64), nn.SiLU(),
            nn.Linear(64, 1), nn.Sigmoid(),
        )

    def forward(self, x_cont, x_cat):
        embs = [emb(x_cat[:, i]) for i, emb in enumerate(self.embeddings)]
        return self.net(torch.cat([x_cont] + embs, dim=1))


class BinaryFocalLoss(nn.Module):
    def __init__(self, alpha=0.75, gamma=2.0):
        super().__init__(); self.alpha = alpha; self.gamma = gamma

    def forward(self, inputs, targets):
        inputs = torch.clamp(inputs, 1e-7, 1 - 1e-7)
        bce = -(targets * torch.log(inputs) + (1 - targets) * torch.log(1 - inputs))
        p_t = targets * inputs + (1 - targets) * (1 - inputs)
        return (targets * self.alpha + (1 - targets) * (1 - self.alpha)) * (1 - p_t) ** self.gamma * bce


class MinMaxScaler:
    def __init__(self): self.min_ = []; self.max_ = []

    def fit(self, X):
        self.min_ = X.min(dim=0).values.tolist(); self.max_ = X.max(dim=0).values.tolist(); return self

    def transform(self, X):
        mn = torch.tensor(self.min_, dtype=torch.float32); mx = torch.tensor(self.max_, dtype=torch.float32)
        return (X - mn) / (mx - mn).clamp(min=1e-8)

    def fit_transform(self, X): return self.fit(X).transform(X)
    def to_dict(self): return {"min": self.min_, "max": self.max_}

    @classmethod
    def from_dict(cls, d):
        s = cls(); s.min_ = d["min"]; s.max_ = d["max"]; return s


def engineer_features_single(d: dict) -> tuple:
    income    = float(d.get("monthly_income", 50000))
    expenses  = float(d.get("monthly_expenses", 25000))
    cibil     = float(d.get("credit_score", 650))
    emp_years = float(d.get("employment_years", 5))
    loans     = float(d.get("existing_loans", 1))
    amount    = float(d.get("requested_amount", d.get("amount", 500000)))
    tenure    = float(d.get("tenure_months", 36))
    savings   = float(d.get("savings_consistency", 0.5))
    dti              = expenses / max(income, 1.0)
    affordability    = amount / max(income * tenure, 1.0)
    surplus_cashflow = (income - expenses) / max(income, 1.0)
    credit_burden    = amount / max(cibil * (emp_years + 1.0), 1.0)
    log_income       = math.log1p(income)
    log_amount       = math.log1p(amount)
    cont = [cibil/900, dti, affordability, surplus_cashflow, credit_burden,
            emp_years/30, loans/10, savings, log_income/15, log_amount/15]
    cat  = [SEGMENT_MAP.get(str(d.get("segment","salaried_prime")),0),
            GENDER_MAP.get(str(d.get("gender","male")),0),
            CITY_MAP.get(str(d.get("city","Mumbai")),0)]
    return cont, cat


def engineer_features_batch(raw_data: list) -> tuple:
    cont_all, cat_all, targets = [], [], []
    for d in raw_data:
        cont, cat = engineer_features_single(d)
        cont_all.append(cont); cat_all.append(cat)
        income    = float(d.get("monthly_income", 50000))
        expenses  = float(d.get("monthly_expenses", 25000))
        cibil     = float(d.get("credit_score", 650))
        amount    = float(d.get("requested_amount", d.get("amount", 500000)))
        tenure    = float(d.get("tenure_months", 36))
        savings   = float(d.get("savings_consistency", 0.5))
        dti           = expenses / max(income, 1.0)
        affordability = amount / max(income * tenure, 1.0)
        pd_true = (0.18 + (720 - cibil)/900 + min(affordability*2.2,0.35)
                   + (dti - 0.45)*0.45 - (savings-0.5)*0.12 + random.gauss(0, 0.04))
        targets.append(1.0 if pd_true > 0.34 else 0.0)
    return (torch.tensor(cont_all, dtype=torch.float32),
            torch.tensor(cat_all, dtype=torch.long),
            torch.tensor(targets, dtype=torch.float32).unsqueeze(1))


def generate_synthetic_dataset(n_samples: int = 2000) -> list:
    random.seed(42)
    cities = list(CITY_MAP.keys()); segments = list(SEGMENT_MAP.keys()); genders = list(GENDER_MAP.keys())
    samples = []
    for _ in range(n_samples):
        income = random.randint(20000, 400000)
        samples.append({
            "monthly_income":    income,
            "monthly_expenses":  income * random.uniform(0.28, 0.88),
            "credit_score":      random.randint(500, 870),
            "employment_years":  round(random.uniform(0.5, 22.0), 1),
            "existing_loans":    random.randint(0, 6),
            "requested_amount":  random.randint(50000, 3000000),
            "tenure_months":     random.choice([12, 24, 36, 48, 60]),
            "savings_consistency": round(random.uniform(0.15, 0.98), 2),
            "segment": random.choice(segments),
            "gender":  random.choice(genders),
            "city":    random.choice(cities),
        })
    return samples


@dataclass
class MLPScoreResult:
    probability_default: float
    attributions: list


class HybridMLPScorer:
    def __init__(self, model: DeepPyTorchCreditMLP, scaler: MinMaxScaler):
        self.model = model; self.scaler = scaler; self.model.eval()

    def predict(self, applicant: dict) -> MLPScoreResult:
        cont_raw, cat = engineer_features_single(applicant)
        x_cont = self.scaler.transform(torch.tensor([cont_raw], dtype=torch.float32))
        x_cont.requires_grad_(True)
        x_cat  = torch.tensor([cat], dtype=torch.long)
        self.model.eval()
        pred = self.model(x_cont, x_cat)
        prob = float(pred.item())
        pred.backward()
        attr = (x_cont.grad.detach()[0] * x_cont.detach()[0]).tolist()
        attributions = []
        for i, (fk, fl) in enumerate(FEATURE_LABELS):
            c = float(attr[i])
            attributions.append({"feature": fk, "label": fl, "value": f"{cont_raw[i]:.3f}",
                                 "contribution": round(c, 4), "direction": "risk" if c > 0 else "protective"})
        attributions.sort(key=lambda x: abs(x["contribution"]), reverse=True)
        return MLPScoreResult(probability_default=prob, attributions=attributions)

    def save(self, directory) -> None:
        path = Path(directory); path.mkdir(parents=True, exist_ok=True)
        torch.save(self.model.state_dict(), path / "hybrid_mlp.pt")
        with open(path / "scaler.json", "w") as f: json.dump(self.scaler.to_dict(), f)
        print(f"[HybridMLPScorer] Saved to {path}")

    @classmethod
    def load(cls, directory) -> "HybridMLPScorer":
        path = Path(directory)
        model = DeepPyTorchCreditMLP()
        model.load_state_dict(torch.load(path / "hybrid_mlp.pt", map_location="cpu", weights_only=True))
        model.eval()
        with open(path / "scaler.json") as f: scaler = MinMaxScaler.from_dict(json.load(f))
        print(f"[HybridMLPScorer] Loaded from {path}")
        return cls(model, scaler)

    @classmethod
    def is_available(cls, directory) -> bool:
        p = Path(directory)
        return (p / "hybrid_mlp.pt").exists() and (p / "scaler.json").exists()


def train_high_accuracy_mlp(n_splits=5, epochs=60, n_samples=2000):
    print("=================================================================")
    print("  Hybrid MLP Credit Risk Trainer - Stratified 5-Fold CV")
    print("=================================================================")
    raw = generate_synthetic_dataset(n_samples)
    x_raw, x_cat, y = engineer_features_batch(raw)
    scaler = MinMaxScaler()
    x_cont = scaler.fit_transform(x_raw)
    pos_idx = (y.squeeze()==1.0).nonzero(as_tuple=True)[0].tolist()
    neg_idx = (y.squeeze()==0.0).nonzero(as_tuple=True)[0].tolist()
    random.seed(42); random.shuffle(pos_idx); random.shuffle(neg_idx)
    pf = len(pos_idx)//n_splits; nf = len(neg_idx)//n_splits
    oof = torch.zeros_like(y); best_auc = 0.0; best_model = None
    for fold in range(n_splits):
        pv = pos_idx[fold*pf:(fold+1)*pf]; nv = neg_idx[fold*nf:(fold+1)*nf]
        vi = torch.tensor(pv+nv, dtype=torch.long)
        ti = torch.tensor([i for i in pos_idx if i not in pv]+[i for i in neg_idx if i not in nv], dtype=torch.long)
        tl = DataLoader(TensorDataset(x_cont[ti],x_cat[ti],y[ti]), batch_size=64, shuffle=True)
        vl = DataLoader(TensorDataset(x_cont[vi],x_cat[vi],y[vi]), batch_size=128)
        model = DeepPyTorchCreditMLP()
        crit = BinaryFocalLoss()
        opt  = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
        sch  = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
        for _ in range(epochs):
            model.train()
            for bc, bcat, by in tl:
                opt.zero_grad()
                loss = crit(model(bc,bcat), by).mean()
                loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step()
            sch.step()
        model.eval(); vp_l=[]; vy_l=[]
        with torch.no_grad():
            for bc, bcat, by in vl: vp_l.append(model(bc,bcat)); vy_l.append(by)
        vp = torch.cat(vp_l); vy = torch.cat(vy_l); oof[vi] = vp
        fa = compute_auc_roc(vy,vp); fks = compute_ks_statistic(vy,vp)
        if fa > best_auc: best_auc = fa; best_model = model
        print(f"   -> Fold {fold+1}/{n_splits} | AUC: {fa:.4f} | KS: {fks:.4f}")
    oof_auc = compute_auc_roc(y,oof); oof_ks = compute_ks_statistic(y,oof)
    print(f"\n  [SUMMARY] OOF AUC: {oof_auc:.4f} | OOF KS: {oof_ks:.4f}")
    print("=================================================================")
    return HybridMLPScorer(best_model, scaler), float(oof_auc), float(oof_ks)


if __name__ == "__main__":
    train_high_accuracy_mlp()
